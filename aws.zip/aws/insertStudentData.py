import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('studentData')

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])

        table.put_item(
            Item={
                "Studentid": body["Studentid"],
                "Name": body["Name"],
                "Class": body["Class"],
                "Age": body["Age"]
            }
        )

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*"
            },
            "body": json.dumps("Student data inserted successfully")
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps(str(e))
        }